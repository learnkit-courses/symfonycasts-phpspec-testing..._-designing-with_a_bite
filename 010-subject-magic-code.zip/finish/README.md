# phpspec: Testing... *Designing* with a Bite

Well hi there! This repository holds the code and script
for the [phpspec: Testing... *Designing* with a Bite](https://symfonycasts.com/screencast/phpspec) course on SymfonyCasts.

## Setup

Woh... there is *no* setup! Just watch the tutorial and have fun!

## Have Ideas, Feedback or an Issue?

If you have suggestions or questions, please feel free to
open an issue on this repository or comment on the course
itself. We're watching both :).

## Thanks!

And as always, thanks so much for your support and letting
us do what we love!

<3 Your friends at SymfonyCasts 
